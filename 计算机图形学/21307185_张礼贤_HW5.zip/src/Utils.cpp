#include "Utils.h"

void BezierCurve::clearAll()
{
	m_controlPoints.clear();
	m_beizerPoints.clear();
	m_auxiliaryLines.clear();
}

void BezierCurve::clearControlPoints()
{
	m_controlPoints.clear();
	m_auxiliaryLines.clear();
}

void BezierCurve::generateAuxiliaryLines(const double &t)
{
	static const std::array<float, 3> gColors[12] =
	{
		{1, 0, 0},
		{0, 1, 0},
		{1, 0.5f, 0},
		{1, 0, 0.5f},
		{0, 0.5f, 0.5f},
		{0, 0.25f, 0.5f},
		{0.25f, 0.5f, 0},
		{0.5f, 0, 1},
		{1, 0.25f, 0.5f},
		{0.5f, 0.5f, 0.5f},
		{0.25f, 0.25f, 0.25f},
		{0.125f, 0.125f, 0.125f}
	};

	m_auxiliaryLines.clear();

	auto points = m_controlPoints;
	int level = 1;
	while (points.size() >= 2)
	{

		std::vector<Point2D> tmp;
		for (int i = 0; i < points.size() - 1; ++i)
		{
			Point2D point = Point2D::lerp(points[i], points[i + 1], t);
			point.color = { Uint8(gColors[level][0] * 255), Uint8(gColors[level][1] * 255), Uint8(gColors[level][2] * 255) };
			tmp.push_back(point);
		}

		for (int i = 0; i < tmp.size() - 1; ++i)
		{
			const auto &p0 = tmp[i];
			const auto &p1 = tmp[i + 1];
			Line2D line(p0.x, p0.y, p1.x, p1.y);
			line.color = p0.color;
			m_auxiliaryLines.push_back(line);
		}

		level = (level + 1) % 12;
		points = std::move(tmp);
	}
}

void BezierCurve::addControlPoints(int x, int y)
{
	Point2D point(x, y);
	m_controlPoints.push_back(point);
}

void BezierCurve::drawControlPointsAndLines(WindowsApp* winApp) const
{
	if (m_controlPoints.empty())
		return;
	for (size_t i = 0; i < m_controlPoints.size() - 1; ++i)
	{
		const auto &p0 = m_controlPoints[i];
		const auto &p1 = m_controlPoints[i + 1];
		winApp->drawLine(255, 0, 0, p0.x + 0.5, p0.y + 0.5, p1.x + 0.5, p1.y + 0.5);
	}

	for (const auto &p : m_controlPoints)
	{
		winApp->drawRectFill(255, 0, 0, p.x + 0.5 - 3, p.y + 0.5 - 3, 6, 6);
	}
}

void BezierCurve::drawBezierCurvePoints(WindowsApp* winApp) const
{
	if (m_beizerPoints.empty())
		return;

	for (const auto &beizerPoints : m_beizerPoints)
	{
		for (size_t i = 0; i < beizerPoints.size(); ++i)
		{
			const auto &p = beizerPoints[i];
			winApp->drawRectFill(255, 255, 255, p.x + 0.5 - 2, p.y + 0.5 - 2, 4, 4);
		}
	}
}

void BezierCurve::drawAuxiliaryLines(WindowsApp *winApp) const
{
	for (size_t i = 0; i < m_auxiliaryLines.size(); ++i)
	{
		const auto &line = m_auxiliaryLines[i];
		winApp->drawLine(line.color[0], line.color[1], line.color[2], line.x0 + 0.5, line.y0 + 0.5, line.x1 + 0.5, line.y1 + 0.5);
		winApp->drawRectFill(line.color[0], line.color[1], line.color[2], line.x0 + 0.5 - 3, line.y0 + 0.5 - 3, 6, 6);
		winApp->drawRectFill(line.color[0], line.color[1], line.color[2], line.x1 + 0.5 - 3, line.y1 + 0.5 - 3, 6, 6);
	}
}

void BezierCurve::evaluate(const double &t)
{
	// Visualization of auxiliary lines
	generateAuxiliaryLines(t);

	// Task1
	//Point2D bp = basicTask(m_controlPoints, t);

	// Task2
	Point2D bp = improvementTask(m_controlPoints, t);

	m_beizerPoints.back().push_back(bp);
}

Point2D BezierCurve::basicTask(const std::vector<Point2D>& points, const double& t) const
{
	if (points.size() < 2)
		throw std::invalid_argument("At least two control points are required.");

	// Copy the original control points
	std::vector<Point2D> tmp(points);
	double res_x = 0.0;
	double res_y = 0.0;
	double step_i = 1.0f;
	double step_n = 1.0f;
	int n = tmp.size() - 1;
	double pow_t = 1.0f;
	double pow_nt = pow((1-t),tmp.size()-1);

	for (size_t i = 0; i <= n; ++i)
	{
		// Linear interpolation between adjacent control points
		//Point2D interpolated = Point2D::lerp(tmp[i], tmp[i + 1], t);
		//nextLevel.push_back(interpolated);
		if (i == 0)
		{
			res_x += pow_nt * tmp[i].x;
			res_y += pow_nt * tmp[i].y;
		}
		else
		{
			step_i *= i;
			pow_t *= t;
			step_n *= (n - i + 1);
			pow_nt /= (1 - t);

			double temp =  step_n * pow_t * pow_nt / step_i;
			res_x += tmp[i].x * temp;
			res_y += tmp[i].y * temp;
		}
	}

	// The final point is the result of the basic Bezier curve algorithm
	return Point2D(res_x,res_y);
}


Point2D BezierCurve::improvementTask(const std::vector<Point2D>& points, const double& t) const
{
	if (points.size() < 2)
		throw std::invalid_argument("At least two control points are required.");

	std::vector<Point2D> tmp(points);

	while (tmp.size() > 1)
	{
		std::vector<Point2D> nextLevel;
		for (size_t i = 0; i < tmp.size() - 1; ++i)
		{
			// ʹ�� De Casteljau �㷨�����ڿ��Ƶ�֮����в�ֵ
			Point2D interpolated = Point2D::lerp(tmp[i], tmp[i + 1], t);
			nextLevel.push_back(interpolated);
		}
		tmp = std::move(nextLevel);
	}

	// ����ʣ�µĵ���ʹ�� De Casteljau �㷨�Ľ��ı��������ߵĽ��
	return tmp[0];
}