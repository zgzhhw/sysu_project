import os
import json
import base64
from xmlrpc.client import ServerProxy

# 连接RPC服务器
rpc_server = ServerProxy(f'http://localhost:8000', allow_none=True)

# 缓存目录
CACHE_DIR = 'client_cache'
LOCAL_DIR = 'client_files'

# 确保缓存目录存在
os.makedirs(CACHE_DIR, exist_ok=True)
os.makedirs(LOCAL_DIR, exist_ok=True)

def read_file_with_cache(file_name):

    cache_file_path = os.path.join(CACHE_DIR, f'{file_name}_cache.json')

    # 检查缓存文件是否存在
    if os.path.exists(cache_file_path):
        print(f"从缓存中读取文件 {file_name} 的信息")
        with open(cache_file_path, 'r') as cache_file:
            return json.load(cache_file)
    else:
        # 调用远程RPC方法
        print(f"远程调用读取文件 {file_name} 的信息")
        file_info = rpc_server.read_file(file_name)
        # 将文件信息存入缓存文件
        with open(cache_file_path, 'w') as cache_file:
            json.dump(file_info, cache_file, indent=2)
        return file_info

def delete_file_with_cache(file_name):

    cache_file_path = os.path.join(CACHE_DIR, f'{file_name}_cache.json')
    client_file_path = os.path.join(LOCAL_DIR, file_name)

    # 删除缓存文件
    if os.path.exists(client_file_path):
        os.remove(client_file_path)
        print(f"删除文件 {file_name} 的本地副本")

    if os.path.exists(cache_file_path):
        os.remove(cache_file_path)
        print(f"删除文件 {file_name} 的缓存")

    # 调用远程RPC方法
    response = rpc_server.delete_file(file_name)
    return response

def create_file_local(file_name):

    local_file_path = os.path.join(LOCAL_DIR, file_name)

    # 在本地缓存中创建一个对应的文件
    with open(local_file_path, 'w') as local_file:
        local_file.write("")

    print(f"在本地缓存中创建文件 {file_name}")

def write_back(file_name, data):

    cache_file_path = os.path.join(CACHE_DIR, f'{file_name}_cache.json')

    # 更新本地缓存
    with open(cache_file_path, 'w') as cache_file:
        json.dump(data, cache_file, indent=2)

    print(f"使用写回算法更新本地缓存 {file_name}")

def upload_file(file_path):
    if not os.path.exists(file_path):
        print(f"文件 {file_path} 不存在")
        return

    file_name = os.path.basename(file_path)
    client_file_path = os.path.join(LOCAL_DIR, file_name)

    # 将指定路径的文件复制到本地文件夹
    with open(file_path, 'rb') as source_file:
        with open(client_file_path, 'wb') as destination_file:
            destination_file.write(source_file.read())

    # 读取本地文件并将其转换为base64编码的字符串
    with open(client_file_path, 'rb') as file:
        file_data = base64.b64encode(file.read()).decode()

    # 调用远程RPC方法上传文件
    response = rpc_server.upload_file(file_name, file_data)
    print(response)

def download_file(file_name):
    try:
        # 调用远程RPC方法下载文件
        file_info = rpc_server.download_file(file_name)

        if 'file_data' in file_info and 'file_name' in file_info:
            file_data = base64.b64decode(file_info['file_data'])
            client_file_path = os.path.join(LOCAL_DIR, file_info['file_name'])

            # 将文件数据写入客户端文件夹
            with open(client_file_path, 'wb') as file:
                file.write(file_data)

            print(f"文件 {file_name} 下载成功到 {client_file_path}")
        else:
            print(f"下载文件 {file_name} 失败：{file_info}")

    except Exception as e:
        print(f"Error during file download: {e}")

try:
    while True:
        command = input("请输入命令(create/delete/read/write/upload/download/exit): ")

        if command == "exit":
            break

        elif command in ['create', 'delete', 'read', 'write', 'download']:
            file_name = input("请输入文件名: ")

            if command == "write":
                data = input("请输入要写入的数据: ")
                write_back(file_name, data)
                # 异步更新服务器
                rpc_server.write_file(file_name, data)

            if command == "read":
                # 使用缓存的读取方法
                file_info = read_file_with_cache(file_name)
                print(file_info)

            elif command == "delete":
                # 使用带有缓存删除的方法
                response = delete_file_with_cache(file_name)
                print(response)

            elif command == "create":
                # 在本地缓存中创建一个对应的文件
                # create_file_local(file_name)
                # 调用远程RPC方法
                response = rpc_server.create_file(file_name)
                print(response)

            elif command == 'download':
                download_file(file_name)


        elif command in ['upload']:

            if command == "upload":
                file_path = input("请输入文件路径: ")
                # 上传指定路径的文件到服务器
                upload_file(file_path)

except Exception as e:
    print(f"Error: {e}")
